#ifndef PHP_NDBM_H
#define PHP_NDBM_H

#if DBA_NDBM

#include "php_dba.h"

DBA_FUNCS(ndbm);

#endif

#endif
